import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-booking-by-pendings',
  templateUrl: './view-booking-by-pendings.component.html',
  styleUrls: ['./view-booking-by-pendings.component.css']
})
export class ViewBookingByPendingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
