import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-booking',
  templateUrl: './manage-booking.component.html',
  styleUrls: ['./manage-booking.component.css']
})
export class ManageBookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
