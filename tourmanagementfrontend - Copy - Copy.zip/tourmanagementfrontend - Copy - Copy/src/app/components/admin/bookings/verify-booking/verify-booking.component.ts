import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-booking',
  templateUrl: './verify-booking.component.html',
  styleUrls: ['./verify-booking.component.css']
})
export class VerifyBookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
